-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 16, 2021 at 02:16 AM
-- Server version: 10.3.32-MariaDB-0ubuntu0.20.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hybrid_160419137`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `likes` int(255) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `post_id`, `user_id`, `comment`, `likes`) VALUES
(11, 1, 8, 'test', 1),
(12, 3, 8, 'bababoey', 1);

-- --------------------------------------------------------

--
-- Table structure for table `postingan`
--

CREATE TABLE `postingan` (
  `id` int(11) NOT NULL,
  `poster_id` int(11) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `publish_date` datetime NOT NULL DEFAULT current_timestamp(),
  `likes` int(11) NOT NULL DEFAULT 0,
  `url` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `postingan`
--

INSERT INTO `postingan` (`id`, `poster_id`, `description`, `publish_date`, `likes`, `url`) VALUES
(1, 1, 'Among Us adalah sebuah permainan pemain jamak daring yang dikembangkan dan dipublikasikan oleh studio permainan asal Amerika Serikat, InnerSloth, dan dirilis pada tanggal 15 Juni 2018. Permainan berlangsung dalam latar bertema ruang angkasa dimana masing-masing pemain mendapatkan salah satu dari dua peran, sebagian besar menjadi Crewmates, dan lainnya menjadi Impostor. Tujuan Crewmates adalah mengidentifikasi Impostor, menghilangkan mereka, dan menyelesaikan tugas yang tersedia di sekeliling peta, dan tujuan Impostor adalah untuk membunuh Crewmates tanpa ketahuan dan menggagalkan misi/tugas dari Crewmates.', '2021-12-15 02:08:53', 13, 'https://awsimages.detik.net.id/community/media/visual/2021/11/10/update-besa-besaran-among-us-ungkap-seluruh-karakter-baru_169.png?w=700&q=90'),
(2, 2, 'Naruto adalah sebuah serial manga karya Masashi Kishimoto yang diadaptasi menjadi serial anime. Manga Naruto bercerita seputar kehidupan tokoh utamanya, Naruto Uzumaki, seorang ninja yang hiperaktif, periang, dan ambisius yang ingin mewujudkan keinginannya untuk mendapatkan gelar Hokage, pemimpin dan ninja terkuat di desanya. Serial ini didasarkan pada komik one-shot oleh Kishimoto yang diterbitkan dalam edisi Akamaru Jump pada Agustus 1997', '2021-12-08 18:55:39', 59, 'https://i1.wp.com/narmadi.com/id/wp-content/uploads/2020/05/mewarnai-gambar-kartun-narmadi.comid_.jpg?resize=696%2C466&ssl=1'),
(3, 3, 'Minions adalah sebuah film komedi animasi komputer 3D, Amerika Serikat yang tayang pada tahun 2015 dan merupakan prekuel /spin-off dari Despicable Me (2010) dan Despicable Me 2 (2013). Film tersebut diproduksi oleh Illumination Entertainment dan distribusikan oleh Universal Pictures. Ditulis oleh Brian Lynch, film tersebut disutradarai oleh Pierre Coffin dan Kyle Balda, dan diproduksi oleh Chris Meledandri dan Janet Healy. Pada film tersebut diisi suara dengan 4 bahasa yaitu Italia, Spanyol, Inggris dan Indonesia. Film ini dibintangi oleh Pierre Coffin (sebagai Minion), Sandra Bullock, Jon Hamm, Michael Keaton, Allison Janney, Steve Coogan, dan Geoffrey Rush. Film ini pertama diprediksi di kredit penutupan dari Despicable Me 2, di mana Stuart, Kevin dan Bob, tiga dari Minion, yang terlihat sedang mengikuti audisi untuk film ini.', '2021-12-09 18:55:39', 36, 'https://broonet.com/wp-content/uploads/2020/03/mewarnai-gambar-kartun-9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE `userlogin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `pic_url` varchar(1000) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`id`, `username`, `bio`, `pic_url`, `email`, `password`) VALUES
(1, 'david', NULL, 'https://cf.shopee.co.id/file/1740a66d75c848b38c85ade20a2505e2', 'david@gmail.com', '123'),
(2, 'wildan', NULL, 'https://cf.shopee.co.id/file/1740a66d75c848b38c85ade20a2505e2', 'wildan@gmail.com', '123'),
(3, 'pandu', NULL, 'https://cf.shopee.co.id/file/1740a66d75c848b38c85ade20a2505e2', 'pandu@gmail.com', '123'),
(5, 'wulfer', 'woof wooof uwu', 'https://ubaya.fun/hybrid/160419137/uas/img/profiles/default.jpg', 'woof@woof.com', '1234'),
(7, 'flashgram', 'Halo ini Flashgram Pusat Ionic', 'https://ubaya.fun/hybrid/160419137/uas/img/profiles/default.jpg', 'flashgram@gmail.com', 'flashgram123'),
(8, 'falcrofaircrix', '1234', 'https://ubaya.fun/hybrid/160419137/uas/img/profiles/default.jpg', 'falcro@falcro.com', '12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `postingan`
--
ALTER TABLE `postingan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `poster_id` (`poster_id`) USING BTREE;

--
-- Indexes for table `userlogin`
--
ALTER TABLE `userlogin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `postingan`
--
ALTER TABLE `postingan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `userlogin`
--
ALTER TABLE `userlogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `postingan` (`id`),
  ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `userlogin` (`id`);

--
-- Constraints for table `postingan`
--
ALTER TABLE `postingan`
  ADD CONSTRAINT `postingan_ibfk_1` FOREIGN KEY (`poster_id`) REFERENCES `userlogin` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
