<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);

    $sql = "UPDATE comment SET likes = likes+1 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if($stmt->execute()){
        $arr=["result"=>"success","data"=>"post likes have been changed"];
    }else {
        $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
    }
    
    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>