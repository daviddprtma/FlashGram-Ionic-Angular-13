<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);

    $img = str_replace('data:image/jpeg;base64,','',$pic);
    $img = str_replace(' ','+',$img);
    $data = base64_decode($img);
    file_put_contents('/var/www/html/hybrid/160419137/uas/img/posts/post'.$posterid.date("djmyHis").'.jpg', $data);
    $url='https://ubaya.fun/hybrid/160419137/uas/img/posts/post'.$posterid.date("djmyHis").'.jpg';

    $sql = "INSERT INTO postingan(poster_id, description, url) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss",$posterid,$desc,$url);
    if($stmt->execute()){
        $arr=["result"=>"success","data"=>"post succesfully created"];
        
    } else {
        $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
    }
    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>