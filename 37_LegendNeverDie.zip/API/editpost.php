<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);

    if(isset($_POST['pic'])){
        $img = str_replace('data:image/jpeg;base64,','',$pic);
        $img = str_replace(' ','+',$img);
        $data = base64_decode($img);
        file_put_contents('/var/www/html/hybrid/160419137/uas/img/posts/post'.$posterid.date("djmyHis").'.jpg', $data);
        $url='https://ubaya.fun/hybrid/160419137/uas/img/posts/post'.$posterid.date("djmyHis").'.jpg';

        $curdate = date("Y-m-d H:i:s");

        $sql = "UPDATE postingan SET description=?, publish_date=?, url=? WHERE poster_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi",$desc, $curdate, $url, $id);
        if($stmt->execute()){
            $arr=["result"=>"success","data"=>"post data have been changed"];
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }else{
        $sql = "UPDATE postingan SET likes = likes+1 WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        if($stmt->execute()){
            $arr=["result"=>"success","data"=>"post likes have been changed"];
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }
    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>