<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);
    if(isset($_POST['password'])){
        $sql = "SELECT * FROM userlogin WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s",$username);
        if($stmt->execute()){
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                if($password==$row['password']){
                    $arr=["result"=>"success","data"=>$row["id"]];
                }else{
                    $arr=["result"=>"error","message"=>"Password not match"];
                }
            }else{
                $arr=["result"=>"error","message"=>"No user found"];
            }
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }else{
        $sql = "SELECT * FROM userlogin WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i",$id);
        if($stmt->execute()){
            $result = $stmt->get_result();
            $data=[];
            if ($result->num_rows > 0) {
                while($r=mysqli_fetch_assoc($result)){
                    array_push($data,$r);
                    $arr=["result"=>"success","data"=>$data];
                }
            }else{
                $arr=["result"=>"error","message"=>"No user found"];
            }
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }

    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>