<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }

    extract($_POST);
    if(isset($_POST['id'])){
        $sql = "SELECT postingan.id, userlogin.id AS user_id,  userlogin.username, userlogin.pic_url, postingan.description, postingan.publish_date, postingan.likes, postingan.url FROM postingan INNER JOIN userlogin on postingan.poster_id = userlogin.id  WHERE postingan.id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i",$id);

        if($stmt->execute()){
            $result = $stmt->get_result();
            $data=[];
            if ($result->num_rows > 0) {
                while($r=mysqli_fetch_assoc($result)){
                    array_push($data,$r);
                    $arr=["result"=>"success","data"=>$data];
                }
            }else{
                $arr=["result"=>"error","message"=>"No user found"];
            }
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }else if(isset($_POST['userid'])){
        $sql = "SELECT postingan.id,  userlogin.username, userlogin.pic_url, postingan.description, postingan.publish_date, postingan.likes, postingan.url FROM postingan INNER JOIN userlogin ON postingan.poster_id = userlogin.id WHERE userlogin.id=? ORDER BY postingan.publish_date DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i",$userid);

        if($stmt->execute()){
            $result = $stmt->get_result();
            $data=[];
            if ($result->num_rows > 0) {
                while($r=mysqli_fetch_assoc($result)){
                    array_push($data,$r);
                }
                $arr=["result"=>"success","data"=>$data];
            }else{
                $arr=["result"=>"error","message"=>"user haven't created any post"];
            }
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }else{
        $sql = "SELECT postingan.id, userlogin.id AS user_id,  userlogin.username, userlogin.pic_url, postingan.description, postingan.publish_date, postingan.likes, postingan.url
        FROM postingan INNER JOIN userlogin ON postingan.poster_id = userlogin.id ORDER BY postingan.publish_date DESC";
        $result = $conn->query($sql);
        $data=[];
        if ($result->num_rows > 0) {
            while($r=mysqli_fetch_assoc($result)){
                array_push($data,$r);
            }
            $arr=["result"=>"success","data"=>$data];
        }else{
            $arr=["result"=>"error","message"=>"No post found"];
        }
    }

    echo json_encode($arr);
    $conn->close();
?>