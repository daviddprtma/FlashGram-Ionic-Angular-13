<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }

    extract($_POST);

    $sql = "SELECT comment.id, userlogin.id AS user_id,  userlogin.username, userlogin.pic_url, comment.comment, comment.likes FROM comment INNER JOIN userlogin on comment.user_id = userlogin.id  WHERE comment.post_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i",$id);

    if($stmt->execute()){
        $result = $stmt->get_result();
        $data=[];
        if ($result->num_rows > 0) {
            while($r=mysqli_fetch_assoc($result)){
                array_push($data,$r);
                $arr=["result"=>"success","data"=>$data];
            }
        }else{
            $arr=["result"=>"error","message"=>"No user found"];
        }
    }else {
        $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
    }


    echo json_encode($arr);
    $conn->close();
?>