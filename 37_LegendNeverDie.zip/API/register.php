<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    $defaultprofile = "https://ubaya.fun/hybrid/160419137/uas/img/profiles/default.jpg";
    extract($_POST);
    $sql = "INSERT INTO userlogin(username, email, password, bio, pic_url) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss",$username,$email,$password,$bio,$defaultprofile);
    if($stmt->execute()){
        $arr=["result"=>"success","data"=>"account succesfully created"];
        
    } else {
        $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
    }
    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>