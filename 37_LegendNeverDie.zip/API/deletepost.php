<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);
    $commentsql = "DELETE FROM comment WHERE post_id=?";
    $commentstmt = $conn->prepare($commentsql);
    $commentstmt->bind_param("i",$id);
    if($commentstmt->execute()){
        $sql = "DELETE FROM postingan WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i",$id);
        if($stmt->execute()){
            $arr=["result"=>"success","data"=>"Post have been deleted"];
            
        } else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
        
    } else {
        $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
    }
    echo json_encode($arr);

    $conn->close();
?>