<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);

    $sql = "INSERT INTO comment(post_id, user_id, comment) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iis",$postid,$userid,$comment);
    if($stmt->execute()){
        $arr=["result"=>"success","data"=>"comment succesfully created"];
        
    } else {
        $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
    }
    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>