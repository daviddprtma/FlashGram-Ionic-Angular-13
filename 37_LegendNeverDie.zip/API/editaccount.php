<?php
    header("Access-Control-Allow-Origin: *");
    $conn = new mysqli("localhost", "hybrid_160419137","ubaya","hybrid_160419137");

    if($conn->connect_error) {
        $arr= ["result"=>"error","message"=>"unable to connect"];
    }
    
    extract($_POST);
    if(isset($_POST['email'])){
        $sql = "UPDATE userlogin SET email=? WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss",$email,$username);
        if($stmt->execute()){
            $arr=["result"=>"success","data"=>"user's email have been changed"];
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }else if(isset($_POST['password'])){
        $stmtpass = $conn->prepare($sqlchangepass);
        $stmtpass->bind_param("ss",$password,$username);
        if($stmtpass->execute()){
            $arr=["result"=>"success","data"=>"user's password have been changed!"];
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmtpass->error];
        }
    }else if(isset($_POST['propic'])){
        $img = str_replace('data:image/jpeg;base64,','',$propic);
        $img = str_replace(' ','+',$img);
        $data = base64_decode($img);
        file_put_contents('/var/www/html/hybrid/160419137/uas/img/profiles/prof'.$username.date("djmyHis").'.jpg', $data);
        $url='https://ubaya.fun/hybrid/160419137/uas/img/profiles/prof'.$username.date("djmyHis").'.jpg';

        $sql = "UPDATE userlogin SET pic_url=? WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss",$url,$username);
        if($stmt->execute()){
            $arr=["result"=>"success","data"=>"user's email have been changed"];
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }

    }else if(isset($_POST['bio'])){
        $sql = "UPDATE userlogin SET bio=? WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss",$bio,$username);
        if($stmt->execute()){
            $arr=["result"=>"success","data"=>"user's email have been changed"];
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }else if(isset($_POST['bio'])){
        $sql = "UPDATE userlogin SET username = ? WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss",$newusername,$username);
        if($stmt->execute()){
            $arr=["result"=>"success","data"=>"user's username have been changed"];
        }else {
            $arr= ["result"=>"error","message"=>"Sql error: ".$stmt->error];
        }
    }

    echo json_encode($arr);
    $stmt->close();
    $conn->close();
?>