import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  constructor(private http: HttpClient) { }

  getComment(id: number): Observable<any>{
    let body = new HttpParams();
    body = body.set('id', id);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/getcomment.php', body);
  }

  likesComment(id: number): Observable<any>{
    let body = new HttpParams();
    body = body.set('id', id);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/likescomment.php', body);
  }

  addComment(postid: number, userid: number, comment: string): Observable<any>{
    let body = new HttpParams();
    body = body.set('postid', postid);
    body = body.set('userid',userid);
    body = body.set('comment',comment);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/addcomment.php', body);
  }
}
