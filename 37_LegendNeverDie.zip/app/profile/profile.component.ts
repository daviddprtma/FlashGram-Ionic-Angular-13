/* eslint-disable max-len */
import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { UserService } from '../user.service';
import { UserModel } from '../user.model';
import { ActivatedRoute } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { PostinganService } from '../postingan.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
  user: UserModel;
  userPosts = [];
  isOwnerProfile;
  userNoPost;

  constructor(public route: ActivatedRoute, public main: AppComponent,public ps: PostinganService, public us: UserService, public tc: ToastController) { }

  ngOnInit() {
    const passedId: number = this.route.snapshot.params['id'];
    this.isOwnerProfile = (passedId == this.main.currentUser.id);
    this.setCurrentUser(passedId);
    this.getUserPosts(passedId);
  }


  refresh(){
    this.getUserPosts(this.user.id);
  }

  addLike(arrIndex: number, postIndex: number){
    this.ps.addLike(postIndex).subscribe(
      (data)=>{
        if(data["result"]==="success"){
          this.userPosts[arrIndex].likes++;
        }else{
          this.showToast('Unable to add like, message : ' + data["message"]);
        }
      }
    );
  }

  setCurrentUser(userid: number){
    if(this.isOwnerProfile === true){
      this.user = this.main.currentUser;
    }else{
      this.us.getAccount(userid).subscribe(
        (data2)=>{
          if(data2["result"]=="success"){
            const userData = data2["data"][0];
            this.user = new UserModel(userData["id"],
            userData["username"],
            userData["bio"],
            userData["pic_url"],
            userData["email"]);
          }else{
            this.showToast("unable to get account, message : " + data2["message"]);
          }
        }
      );
    }
  }

  getUserPosts(userid: number){
    this.ps.getPostByUser(userid).subscribe(
      (data)=>{
        if(data["result"]=="success"){
          this.userPosts=data["data"];
        }else{
          this.userNoPost = "User havent created any post";
        }
      }
    );
  }

  async showToast(toastMessage: string) {
    const toast = await this.tc.create({
      message: toastMessage,
      duration: 5000,
    });

    await toast.present();
  }
}
