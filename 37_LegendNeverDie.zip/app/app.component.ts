import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage-angular';
import { UserModel } from './user.model';
import { UserService } from './user.service';
import { ToastController, AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit {
  username='';
  loggeduser: number;
  password='';
  onRegister: boolean=false;
  currentUser: UserModel;

  constructor(private router: Router,private storage: Storage,public ac:AlertController, public us: UserService, public tc: ToastController) {}

  async ngOnInit() {
    await this.storage.create();
    this.loggeduser=await this.storage.get('loggeduserid');

    if(this.loggeduser){
      this.getAccountDetail(this.loggeduser);
      this.router.navigate(['/postfeed']);
    }
  }

  login(){
    this.us.login(this.username,this.password).subscribe(
      (data1)=>{
        if(data1["result"]=="success"){
          this.loggeduser=data1["data"];
          this.storage.set('loggeduserid',this.loggeduser);

          this.getAccountDetail(this.loggeduser);
          this.showToast("Login succesful");

          this.router.navigate(['/postfeed']);
        }else{
          this.showWarning("unable to login, message : " + data1["message"]);
        }
      }
    );
  }

  goToRegister(){
    if(this.onRegister){
      this.onRegister = false;
    }else{
      this.onRegister = true;
    }
  }

  async showToast(toastMessage: string) {
    const toast = await this.tc.create({
      message: toastMessage,
      duration: 5000,
    });

    await toast.present();
  }

  getAccountDetail(id: number){
    this.us.getAccount(id).subscribe(
      (data2)=>{
        if(data2["result"]=="success"){
          const userData = data2["data"][0];
          this.currentUser = new UserModel(userData["id"],
          userData["username"],
          userData["bio"],
          userData["pic_url"],
          userData["email"]);
        }else{
          this.showToast("unable to get account, message : " + data2["message"]);
        }
      }
    );
  }

  async showWarning(warningMessage: string){
    const alert = await this.ac.create({
      header: 'Warning!',
      message: warningMessage,
      buttons: [{
        text: 'OK',
        role: 'cancel',
      }],
    });
    await alert.present();
  }

  async showLogOutWarning(warningMessage: string){
    const alert = await this.ac.create({
      header: 'Warning!',
      message: warningMessage,
      buttons: [{
        text: 'Cancel',
        role: 'cancel',
      },{
        text: 'Log Out',
        cssClass:'danger',
        handler: (msg)=>{
          this.logOut();
        }
      }],
    });
    await alert.present();
  }

  async logOut(){
    await this.storage.remove('loggeduserid');
    this.router.navigate(['/']);
    this.loggeduser = null;
  }
}
