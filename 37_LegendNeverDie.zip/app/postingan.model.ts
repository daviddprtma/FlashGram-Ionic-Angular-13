export class PostinganModel{
  constructor(
    public id: number,
    public user_id: number,
    public username: string,
    public pic_url: string,
    public desc: string,
    public url: string,
    public publish_date: string,
    public likes: number
  ){}
}
