import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { ToastController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-registerform',
  templateUrl: './registerform.component.html',
  styleUrls: ['./registerform.component.scss'],
})
export class RegisterformComponent implements OnInit {
  username='';
  password='';
  repassword='';
  email='';
  bio='';

  constructor(public ac: AlertController,public us: UserService, public tc: ToastController) { }

  ngOnInit() {}

  register(){
    if(this.password === this.repassword){
      this.us.register(this.username,this.password,this.email,this.bio).subscribe(
        (data)=>{
          if(data["result"]==="success"){
            this.showToast('Account have succesfully created');
          }else{
            this.showWarning('unable to register account, message : ' + data["message"]);
          }
        }
      );
    }else{
      this.showWarning('unable to register account, message : password didnt match');
    }
  }


  async showToast(toastMessage: string) {
    const toast = await this.tc.create({
      message: toastMessage,
      duration: 5000,
    });

    await toast.present();
  }

  async showWarning(warningMessage: string){
    const alert = await this.ac.create({
      header: 'Warning!',
      message: warningMessage,
      buttons: [{
        text: 'OK',
        role: 'cancel',
      }],
    });
    await alert.present();
  }
}
