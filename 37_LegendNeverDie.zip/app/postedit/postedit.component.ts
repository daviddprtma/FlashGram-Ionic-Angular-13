import { Component, OnInit } from '@angular/core';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { ToastController, AlertController } from '@ionic/angular';
import { PostinganService } from '../postingan.service';
import { PostinganModel } from '../postingan.model';
import { Router, ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-postedit',
  templateUrl: './postedit.component.html',
  styleUrls: ['./postedit.component.scss'],
})
export class PosteditComponent implements OnInit {
  post: PostinganModel;

  cameraOption: CameraOptions = {
    quality: 50,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    sourceType: this.camera.PictureSourceType.CAMERA,
    saveToPhotoAlbum:true,
    targetWidth: 640,
    targetHeight: 640
  };
  galleryOption: CameraOptions = {
    quality: 50,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
    targetWidth: 640,
    targetHeight: 640
  };

  constructor(private router: Router, public acRoute: ActivatedRoute, public ps: PostinganService, public ac: AlertController, public tc: ToastController,public camera: Camera) { }

  ngOnInit() {
    const postid = this.acRoute.snapshot.params['id'];

    this.getPostDetail(postid);
  }

  getPostDetail(id: number){
    this.ps.getPostById(id).subscribe(
      (data)=>{
        if(data["result"]=="success"){
          const postData = data["data"][0];
          this.post = new PostinganModel(
            postData["id"],
            postData["user_id"],
            postData["username"],
            postData["pic_url"],
            postData["description"],
            postData["url"],
            postData["publish_date"],
            postData["likes"]
          );
        }else{
          this.showToast("error in fetching post details, message : " + data["message"]);
        }
      }
    );
  }


  uploadGallery(){
    this.camera.getPicture(this.galleryOption).then(
      (imageData)=>{
        const base64Image = 'data:image/jpeg;base64,' + imageData;
        this.post.url = base64Image;
      },(err)=>{
        this.showWarning("Unable to get image, message" + err);
      }
    );
  }

  takePhoto(){
    this.camera.getPicture(this.cameraOption).then(
      (imageData)=>{
        const base64Image = 'data:image/jpeg;base64,' + imageData;
        this.post.url = base64Image;
      },(err)=>{
        this.showWarning("Unable to take image, message" + err);
      }
    );
  }

  editpost(){
    this.ps.editPost(this.post.id, this.post.desc, this.post.url).subscribe(
      (data)=>{
        if(data["result"]==="success"){
          this.showToast("Post succesfully edited");
          this.router.navigate(['/profile/'+this.post.user_id]);
        }else{
          this.showWarning('unable to edit Post, message : ' + data["message"]);
        }
      }
    );
  }

  deletepost(){
    this.showDeleteWarning("Are you sure do you want to delete this post?");
  }

  async showToast(toastMessage: string) {
    const toast = await this.tc.create({
      message: toastMessage,
      duration: 5000,
    });

    await toast.present();
  }

  async showDeleteWarning(warningMessage: string){
    const alert = await this.ac.create({
      header: 'Warning!',
      message: warningMessage,
      buttons: [{
        text: 'Cancel',
        role: 'cancel',
      },{
        text: 'Delete Post',
        cssClass:'danger',
        handler: (msg)=>{
          this.ps.delete(this.post.id).subscribe(
            (data)=>{
              if(data["result"]==="success"){
                this.showToast("Post succesfully deleted");
                this.router.navigate(['/profile/'+this.post.user_id]);
              }else{
                this.showWarning('unable to delete Post, message : ' + data["message"]);
              }
            }
          );
        }
      }],
    });
    await alert.present();
  }

  async showWarning(warningMessage: string){
    const alert = await this.ac.create({
      header: 'Warning!',
      message: warningMessage,
      buttons: [{
        text: 'OK',
        role: 'cancel',
      }],
    });
    await alert.present();
  }
}
