import { Component, OnInit } from '@angular/core';
import { PostinganService } from '../postingan.service';
import { ToastController } from '@ionic/angular';
import { AppComponent } from '../app.component';
@Component({
  selector: 'app-postfeed',
  templateUrl: './postfeed.component.html',
  styleUrls: ['./postfeed.component.scss'],
})
export class PostfeedComponent implements OnInit {
  posts = [];
  userid;

  constructor(public main: AppComponent, public ps: PostinganService, public tc: ToastController) { }

  ngOnInit() {
    this.getPosts();
    this.userid = this.main.currentUser.id;
  }

  refresh(){
    this.getPosts();
  }

  getPosts(){
    this.ps.getPosts().subscribe(
      (data)=>{
        if(data["result"]=="success"){
          this.posts=data["data"];
        }else{
          this.showToast("error in fetching posts, message : " + data["message"]);
        }
      }
    );
  }

  addLike(arrIndex: number, postIndex: number){
    this.ps.addLike(postIndex).subscribe(
      (data)=>{
        if(data["result"]==="success"){
          this.posts[arrIndex].likes++;
        }else{
          this.showToast('Unable to add like, message : ' + data["message"]);
        }
      }
    );
  }

  async showToast(toastMessage: string) {
    const toast = await this.tc.create({
      message: toastMessage,
      duration: 5000,
    });

    await toast.present();
  }
}
