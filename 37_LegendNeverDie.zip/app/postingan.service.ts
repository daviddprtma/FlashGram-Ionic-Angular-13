import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PostinganService {

  constructor(private http: HttpClient) { }

  getPosts(): Observable<any>{
    return this.http.get('https://ubaya.fun/hybrid/160419137/uas/getpost.php');
  }

  getPostById(id: number): Observable<any>{
    let body = new HttpParams();
    body = body.set('id', id);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/getpost.php',body);
  }

  getPostByUser(userid: number): Observable<any>{
    let body = new HttpParams();
    body = body.set('userid', userid);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/getpost.php',body);
  }

  addPost(posterId: number, desc: string, pic: string): Observable<any>{
    let body = new HttpParams();
    body = body.set('posterid', posterId);
    body = body.set('desc', desc);
    body = body.set('pic', pic);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/addpost.php',body);
  }

  addLike(id: number): Observable<any>{
    let body = new HttpParams();
    body = body.set('id',id);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/editpost.php',body);
  }

  editPost(posterId: number, desc: string, pic: string): Observable<any>{
    let body = new HttpParams();
    body = body.set('desc', desc);
    body = body.set('pic', pic);
    body = body.set('id', posterId);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/editpost.php',body);
  }

  delete(id: number){
    let body = new HttpParams();
    body = body.set('id',id);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/deletepost.php',body);
  }
}
