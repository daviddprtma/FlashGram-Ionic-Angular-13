import { TestBed } from '@angular/core/testing';

import { PostinganService } from './postingan.service';

describe('PostinganService', () => {
  let service: PostinganService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PostinganService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
