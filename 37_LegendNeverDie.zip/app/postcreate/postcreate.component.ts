import { Component, OnInit } from '@angular/core';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { ToastController, AlertController } from '@ionic/angular';
import { PostinganService } from '../postingan.service';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-postcreate',
  templateUrl: './postcreate.component.html',
  styleUrls: ['./postcreate.component.scss'],
})
export class PostcreateComponent implements OnInit {
  pic;
  desc;
  userid;
  cameraOption: CameraOptions = {
    quality: 50,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    sourceType: this.camera.PictureSourceType.CAMERA,
    saveToPhotoAlbum:true,
    targetWidth: 640,
    targetHeight: 640
  };
  galleryOption: CameraOptions = {
    quality: 50,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
    targetWidth: 640,
    targetHeight: 640
  };

  constructor(private router: Router, public main: AppComponent, public ps: PostinganService, public ac: AlertController, public tc: ToastController,public camera: Camera) { }

  ngOnInit() {
    this.userid = this.main.currentUser.id;
  }

  post(){
    this.ps.addPost(this.userid,this.desc,this.pic).subscribe(
      (data)=>{
        if(data["result"]=="success"){
          this.showToast('Post have succesfully created');
          this.router.navigate(['/postfeed']);
        }else{
          this.showWarning('Unable to create post, message : ' + data["message"]);
        }
      }
    );
  }

  uploadGallery(){
    this.camera.getPicture(this.galleryOption).then(
      (imageData)=>{
        const base64Image = 'data:image/jpeg;base64,' + imageData;
        this.pic = base64Image;
      },(err)=>{
        this.showWarning("Unable to get image, message" + err);
      }
    );
  }

  takePhoto(){
    this.camera.getPicture(this.cameraOption).then(
      (imageData)=>{
        const base64Image = 'data:image/jpeg;base64,' + imageData;
        this.pic = base64Image;
      },(err)=>{
        this.showWarning("Unable to take image, message" + err);
      }
    );
  }

  async showToast(toastMessage: string) {
    const toast = await this.tc.create({
      message: toastMessage,
      duration: 5000,
    });

    await toast.present();
  }

  async showWarning(warningMessage: string){
    const alert = await this.ac.create({
      header: 'Warning!',
      message: warningMessage,
      buttons: [{
        text: 'OK',
        role: 'cancel',
      }],
    });
    await alert.present();
  }
}
