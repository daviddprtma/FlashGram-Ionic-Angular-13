export class CommentModel{
  constructor(
    public id: number,
    public user_id: number,
    public username: string,
    public pic_url: string,
    public comment: string,
    public likes: number
  ){}
}
