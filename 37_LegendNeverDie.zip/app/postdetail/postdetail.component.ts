/* eslint-disable max-len */
import { Component, OnInit } from '@angular/core';
import { PostinganService } from '../postingan.service';
import { PostinganModel } from '../postingan.model';
import { CommentService } from '../comment.service';
import { ActivatedRoute } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-postdetail',
  templateUrl: './postdetail.component.html',
  styleUrls: ['./postdetail.component.scss'],
})
export class PostdetailComponent implements OnInit {
  post: PostinganModel;
  comments = [];
  newcomment;
  curUser;
  isOwner;

  constructor(public main: AppComponent,public tc: ToastController, public cs: CommentService ,public ps: PostinganService, public route: ActivatedRoute) { }

  ngOnInit() {
    const postId = this.route.snapshot.params['id'];

    this.curUser = this.main.currentUser.id;

    this.getPostDetail(postId);

    this.getComment(postId);
  }

  getPostDetail(id: number){
    this.ps.getPostById(id).subscribe(
      (data)=>{
        if(data["result"]=="success"){
          const postData = data["data"][0];
          this.post = new PostinganModel(
            postData["id"],
            postData["user_id"],
            postData["username"],
            postData["pic_url"],
            postData["description"],
            postData["url"],
            postData["publish_date"],
            postData["likes"]
          );

          this.isOwner = (this.post.user_id == this.curUser);
        }else{
          this.showToast("error in fetching post details, message : " + data["message"]);
        }
      }
    );
  }

  addLike(postIndex: number){
    this.ps.addLike(postIndex).subscribe(
      (data)=>{
        if(data["result"]==="success"){
          this.post.likes++;
        }else{
          this.showToast('Unable to add like, message : ' + data["message"]);
        }
      }
    );
  }

  getComment(postid: number){
    this.cs.getComment(postid).subscribe(
      (data)=>{
        if(data["result"]=="success"){
          this.comments=data["data"];
        }
      }
    );
  }

  addComment(postid: number){
    this.cs.addComment(postid, this.curUser, this.newcomment).subscribe(
      (data)=>{
        if(data["result"]=="success"){
          this.getComment(this.post.id);
        }else{
          this.showToast("Error in adding comment, message : " + data["message"]);
        }
      }
    );
  }

  addCommentLike(arridx: number,commentIdx: number){
    this.cs.likesComment(commentIdx).subscribe(
      (data)=>{
        if(data["result"]=="success"){
          this.comments[arridx].likes++;
        }else{
          this.showToast('Unable to add likes to comment, message : ' + data["message"]);
        }
      }
    );
  }

  async showToast(toastMessage: string) {
    const toast = await this.tc.create({
      message: toastMessage,
      duration: 5000,
    });

    await toast.present();
  }
}
