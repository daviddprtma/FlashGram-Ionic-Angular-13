import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserModel } from '../user.model';
import { UserService } from '../user.service';
import { ToastController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-profileeditform',
  templateUrl: './profileeditform.component.html',
  styleUrls: ['./profileeditform.component.scss'],
})
export class ProfileeditformComponent implements OnInit {
  user: UserModel;
  newusername;
  newemail;
  newbio;
  newpassword;
  repassword;
  cameraOption: CameraOptions = {
    quality: 50,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    sourceType: this.camera.PictureSourceType.CAMERA,
    saveToPhotoAlbum:true,
    targetWidth: 640,
    targetHeight: 640
  };
  galleryOption: CameraOptions = {
    quality: 50,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
    targetWidth: 640,
    targetHeight: 640
  };


  constructor(public main: AppComponent,public route: ActivatedRoute, public us: UserService, public ac: AlertController, public tc: ToastController, public camera:Camera) { }

  ngOnInit() {
    const passedId: number = this.route.snapshot.params['id'];

    this.us.getAccount(passedId).subscribe(
      (data2)=>{
        if(data2["result"]=="success"){
          const userData = data2["data"][0];
          this.user = new UserModel(userData["id"],
          userData["username"],
          userData["bio"],
          userData["pic_url"],
          userData["email"]);
        }else{
          this.showWarning("unable to get account, message : " + data2["message"]);
        }
      }
    );
  }

  uploadGallery(){
    this.camera.getPicture(this.galleryOption).then(
      (imageData)=>{
        const base64Image = 'data:image/jpeg;base64,' + imageData;
        this.user.proPic = base64Image;
      },(err)=>{
        this.showWarning("Unable to get image, message" + err);
      }
    );
  }

  takePhoto(){
    this.camera.getPicture(this.cameraOption).then(
      (imageData)=>{
        const base64Image = 'data:image/jpeg;base64,' + imageData;
        this.user.proPic = base64Image;
      },(err)=>{
        this.showWarning("Unable to take image, message" + err);
      }
    );
  }

  changeusername(){
    this.us.changeusername(this.user.username, this.newusername).subscribe(
      (data)=>{
        if(data["result"]==="success"){
          this.showToast("Account's username have been changed");
          this.main.getAccountDetail(this.user.id);
        }else{
          this.showWarning('Unable to change account username, message : ' + data["message"]);
        }
      }
    );
  }

  changeemail(){
    this.us.changeemail(this.user.username, this.newemail).subscribe(
      (data)=>{
        if(data["result"]==="success"){
          this.showToast("Account's email have been changed");
          this.main.getAccountDetail(this.user.id);
        }else{
          this.showWarning('Unable to change account email, message : ' + data["message"]);
        }
      }
    );
  }

  changebio(){
    this.us.changebio(this.user.username, this.newbio).subscribe(
      (data)=>{
        if(data["result"]==="success"){
          this.showToast("Account's bio have been changed");
          this.main.getAccountDetail(this.user.id);
        }else{
          this.showWarning('Unable to change account bio, message : ' + data["message"]);
        }
      }
    );
  }

  changeprofilepic(){
    this.us.changeprofilepicture(this.user.username, this.user.proPic).subscribe(
      (data)=>{
        if(data["result"]==="success"){
          this.showToast("Account's profile picture have been changed");
          this.main.getAccountDetail(this.user.id);
        }else{
          this.showWarning('Unable to change account profile picture, message : ' + data["message"]);
        }
      }
    );
  }

  changepassword(){
    if(this.newpassword === this.repassword){
      this.us.changepassword(this.user.username, this.newpassword).subscribe(
        (data)=>{
          if(data["result"]==="success"){
            this.showToast("Account's password have been changed");
          }else{
            this.showWarning('Unable to change account password, message : ' + data["message"]);
          }
        }
      );
    }
  }

  deleteaccount(){
    this.showDeleteWarning("Are you sure do you want to delete your account");
  }

  async showToast(toastMessage: string) {
    const toast = await this.tc.create({
      message: toastMessage,
      duration: 5000,
    });

    await toast.present();
  }

  async showDeleteWarning(warningMessage: string){
    const alert = await this.ac.create({
      header: 'Warning!',
      message: warningMessage,
      buttons: [{
        text: 'Cancel',
        role: 'cancel',
      },{
        text: 'Delete Account',
        cssClass:'danger',
        handler: (msg)=>{
          this.us.delete(this.user.id).subscribe(
            (data)=>{
              if(data["result"]==="success"){
                this.showToast("Account succesfully deleted");
                this.main.logOut();
              }else{
                this.showToast('unable to delete account, message : ' + data["message"]);
              }
            }
          );
        }
      }],
    });
    await alert.present();
  }

  async showWarning(warningMessage: string){
    const alert = await this.ac.create({
      header: 'Warning!',
      message: warningMessage,
      buttons: [{
        text: 'OK',
        role: 'cancel',
      }],
    });
    await alert.present();
  }
}
