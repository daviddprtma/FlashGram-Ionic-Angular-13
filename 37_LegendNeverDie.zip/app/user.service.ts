import { Injectable } from '@angular/core';
import { UserModel } from './user.model';
import { HttpClient } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  getAccount(id: number): Observable<any>{
    let body = new HttpParams();
    body = body.set('id',id);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/login.php', body);
  }

  login(username: string, password: string): Observable<any>{
    let body = new HttpParams();
    body = body.set('username', username);
    body = body.set('password', password);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/login.php', body);
  }

  register(username: string, password: string, email: string, bio: string): Observable<any>{
    let body = new HttpParams();
    body = body.set('username', username);
    body = body.set('password', password);
    body = body.set('email', email);
    body = body.set('bio',bio);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/register.php', body);
  }

  changeemail(username: string, email: string){
    let body = new HttpParams();
    body = body.set('username', username);
    body = body.set('email', email);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/editaccount.php',body);
  }

  changepassword(username: string, password: string){
    let body = new HttpParams();
    body = body.set('username', username);
    body = body.set('password', password);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/editaccount.php',body);
  }

  changeprofilepicture(username: string, propic: string){
    let body = new HttpParams();
    body = body.set('username', username);
    body = body.set('propic', propic);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/editaccount.php',body);
  }

  changebio(username: string, bio: string){
    let body = new HttpParams();
    body = body.set('username', username);
    body = body.set('bio', bio);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/editaccount.php',body);
  }

  changeusername(username: string, newusername: string){
    let body = new HttpParams();
    body = body.set('username', username);
    body = body.set('newusername', newusername);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/editaccount.php',body);
  }

  delete(id: number): Observable<any>{
    let body = new HttpParams();
    body = body.set('id', id);
    return this.http.post('https://ubaya.fun/hybrid/160419137/uas/deleteaccount.php',body);
  }
}
