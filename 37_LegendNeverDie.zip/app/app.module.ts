/* eslint-disable max-len */
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { Camera } from '@ionic-native/camera/ngx';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage-angular';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { RegisterformComponent } from './registerform/registerform.component';
import { ProfileComponent } from './profile/profile.component';
import { ProfileeditformComponent } from './profileeditform/profileeditform.component';
import { PostfeedComponent} from './postfeed/postfeed.component';
import { PostdetailComponent } from './postdetail/postdetail.component';
import { PostcreateComponent } from './postcreate/postcreate.component';
import { PosteditComponent } from './postedit/postedit.component';

import { HttpClientModule } from '@angular/common/http';

import { UserService } from './user.service';
import { PostinganService } from './postingan.service';
import { CommentService } from './comment.service';

const appRoutes: Routes = [
  {path: '', component: AppComponent},
  {path:'register', component: RegisterformComponent},
  {path:'profile/:id', component: ProfileComponent},
  {path:'profileedit/:id', component: ProfileeditformComponent},
  {path:'postfeed', component: PostfeedComponent},
  {path:'postdetail/:id',component: PostdetailComponent},
  {path: 'postcreate', component: PostcreateComponent},
  {path: 'postedit/:id', component: PosteditComponent},
];

@NgModule({
  declarations: [AppComponent, RegisterformComponent, ProfileComponent, ProfileeditformComponent, PostfeedComponent, PostdetailComponent, PostcreateComponent, PosteditComponent],
  entryComponents: [],
  imports: [HttpClientModule,BrowserModule, IonicModule.forRoot(), AppRoutingModule, IonicStorageModule.forRoot(),RouterModule.forRoot(appRoutes), FormsModule],
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }, UserService, PostinganService, CommentService, Camera],
  bootstrap: [AppComponent],
})
export class AppModule {}
