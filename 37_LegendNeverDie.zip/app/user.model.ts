export class UserModel{
  constructor(
    public id: number,
    public username: string,
    public bio: string,
    public proPic: string,
    public email: string
  ){}
}
